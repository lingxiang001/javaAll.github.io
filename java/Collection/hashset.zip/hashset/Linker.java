package Collection.hashset;

public class Linker implements iLinker{
   LinkNode head=null;
   int size;
   public boolean isEmpty() {
       return size==0;
   }
   
    public LinkNode getHead() {
    return head;
}

public void setHead(LinkNode head) {
    if(this.head==null){
        this.head = head;
        size++;
    }
   
}

    @Override
    public void put(Object key, Object val) {
        LinkNode newNode=new LinkNode(null,null,key,val);
        if(isEmpty()){
            head=newNode;
            size++;
        }else{
           
                LinkNode lastNode=getLast();
                if(lastNode != null){
                newNode.setPre(lastNode);
                lastNode.setNext(newNode);
                size++; 
            }
           
        }
        
    }
    private LinkNode getLast(){
        if(!isEmpty()){
            LinkNode node=head;
            while(node.getNext() != null){
                node=node.getNext();
            }
            return node;
        }
        return null;
    }

    @Override
    public void remove(Object key) {
        if(selNode(key) != null){
            LinkNode removeNode=selNode(key); 
            if(removeNode.getPre() == head){
                removeNode.getNext().setPre(null);
                head=removeNode.getNext();
            }else if(removeNode.getNext() == null){
                removeNode.getPre().setNext(null);  
            }else{
                removeNode.getPre().setNext(removeNode.getNext());
                removeNode.getNext().setPre(removeNode.getPre());  
            }
            removeNode=null;
            size--;
        }
    }
    

    @Override
    public Object getVal(Object key) {
       return selNode(key)==null?null:selNode(key).getVal();
    }
    /**
     * 根据key值找出节点
     * @param key
     * @return
     */
    private LinkNode selNode(Object key){
        if(!isEmpty()){
            LinkNode node=head;
            while(node != null){
                if(node.getKey().equals(key) || node.getKey() == key ){
                     return node;
                }else{
                    node=node.getNext();
                }
            }
        }
        return null;
    }
    public int getSize() {
        return size;
    }
    public void setSize(int size) {
        this.size = size;
    }
    

}
