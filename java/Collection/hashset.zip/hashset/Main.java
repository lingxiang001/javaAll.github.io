package Collection.hashset;

public class Main {

    public static void main(String[] args) {
    /*    Linker link=new Linker();
        link.put("1","a");
        link.put("2", "b");
        System.out.println(link.getSize());
       Object v= link.getVal("2");
      
       System.out.println(v);*/
        MyMap<String,String> map=new MyMap<String,String>();
        System.out.println(map.size);
        map.put("1", "a");
        map.put("2", "b");
        map.put("2", "dlx");
        String v=map.getValue("1");
        String v2=map.getValue("2");
        map.remove("1");
         v=map.getValue("1");
        System.out.println(map.size);
        System.out.println(v);
        System.out.println(v2);
        
     }

}
