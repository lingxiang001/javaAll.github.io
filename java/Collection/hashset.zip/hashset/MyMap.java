package Collection.hashset;

import BinarySearchTree.TreeNode;

public class MyMap<K,V> implements MyHashMap<K, V> {
    int size;
    LinkNode[] table=new LinkNode[10];
    LinkNode head;
    Linker link=new Linker();
    @Override
    public void put(K key, V val) {
        int hash = hash(key);
        int i = indexFor(hash, table.length);
        LinkNode newNode=new LinkNode(key,val);
        LinkNode current=table[i];
        if(getValue(key) == null){
            if(current == null){
                table[i]=newNode;
                size++;
            }else{
                head=current;
                link.setHead(head);
                link.put(key, val);
                size++;
            }
        }else{
            change(key,val);
        }
      
        
    }

    private void change(K key, V val) {
        int hash = hash(key);
        int i = indexFor(hash, table.length);
       LinkNode<K,V> current=table[i];
        if(current==null){
            System.out.println("无节点");
        }
        if(current.getKey().equals(key)||current.getKey()==key){
            current.setVal(val);
            
        }
        
    }

    @Override
    public V getValue(K key) {
        int hash = hash(key);
        int i = indexFor(hash, table.length);
        LinkNode<K,V> current=table[i];
        if(current==null){
            return null;
        }
        if(current.getKey().equals(key)||current.getKey()==key){
            return current.getVal();
        }
        return (V) link.getVal(key);
        
    }

    @Override
    public void remove(K key) {
        int hash = hash(key);
        int i = indexFor(hash, table.length);
        LinkNode<K,V> current=table[i];
        if(current !=null){
            if(current.getKey().equals(key)||current.getKey()==key){
                table[i]=null;
                
            }else{ 
                link.remove(key);
            }
            size--;
            }
        
    }
 //以下代码照搬源码
    
    final int hash(Object k) {
        int h =0;
        if (0 != h && k instanceof String) {
            return sun.misc.Hashing.stringHash32((String) k);
        }

        h ^= k.hashCode();

        // This function ensures that hashCodes that differ only by
        // constant multiples at each bit position have a bounded
        // number of collisions (approximately 8 at default load factor).
        h ^= (h >>> 20) ^ (h >>> 12);
        return h ^ (h >>> 7) ^ (h >>> 4);
    }

    /**
     * Returns index for hash code h.
     */
    static int indexFor(int h, int length) {
        // assert Integer.bitCount(length) == 1 : "length must be a non-zero power of 2";
        return h & (length-1);
    }

}
